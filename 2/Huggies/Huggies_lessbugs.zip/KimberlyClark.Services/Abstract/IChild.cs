﻿namespace KimberlyClark.Services.Abstract
{
    public interface IChild
    {
        string BirthDate { get; set; }
        string Gender { get; set; }
    }
}

