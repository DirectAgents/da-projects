﻿namespace Huggies.Web.Models
{
    public interface IRepository
    {
        void Save(Lead lead);
    }
}