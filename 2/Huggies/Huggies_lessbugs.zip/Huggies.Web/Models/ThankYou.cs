﻿namespace Huggies.Web.Models
{
    public class ThankYou
    {
        public bool FirePixel { get; set; }
        public int LeadId { get; set; }
    }
}