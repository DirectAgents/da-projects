﻿using Huggies.Web.Models;
using KimberlyClark.Services.Concrete;

namespace Huggies.Web.Services
{
    public interface IService
    {
        bool SendLead(Lead lead, out ProcessResult processResult);
        void SaveLead(Lead lead, string[] validationErrors);
    }
}